# Results

## Modulith

- cpu 0.5

![alt text](_media/modulith_cpu_0.5.png)

- cpu 1

![alt text](_media/modulith_cpu_1.png)

## Monolith

- cpu 1

![alt text](_media/monolith_cpu_1.png)
