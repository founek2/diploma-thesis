DROP TABLE IF EXISTS rel_item_cart;

--bun:split

DROP TABLE IF EXISTS cart;

--bun:split

DROP TABLE IF EXISTS item;